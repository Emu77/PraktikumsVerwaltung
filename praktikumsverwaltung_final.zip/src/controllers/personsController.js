import { query } from '../db.js';
export async function list(req,res){const {rows}=await query('SELECT * FROM person ORDER BY id');res.render('persons/list',{items:rows,q:''});}
export async function show(req,res){const {id}=req.params;const {rows}=await query('SELECT * FROM person WHERE id=$1',[id]);res.render('persons/show',{item:rows[0]});}
export async function create(req,res){const {vorname,nachname,email,telefon}=req.body;await query('INSERT INTO person(vorname,nachname,email,telefon) VALUES($1,$2,$3,$4)',[vorname,nachname,email,telefon]);res.redirect('/persons');}
export async function update(req,res){const {id}=req.params;const {vorname,nachname,email,telefon}=req.body;await query('UPDATE person SET vorname=$1,nachname=$2,email=$3,telefon=$4 WHERE id=$5',[vorname,nachname,email,telefon,id]);res.redirect('/persons/'+id);}
export async function remove(req,res){const {id}=req.params;await query('DELETE FROM person WHERE id=$1',[id]);res.redirect('/persons');}